//const db = require('../config/db.config')
//const search=require('../routes/search.route')
//
//
//async function Search (req,res){
//    const data = await Product.find()
//    res.send(data);
//}
//
//
//
//
//module.exports = Search