//const express=require('express');
//
//const searchRoute = express.Router()
//
//
//
//
//searchRoute.get("/:key",search)
//
//
//
//
//
//
//module.exports =searchRoute;